Jacob Helhoski
jhelhos1
B00907134

"make" command compiles to create executable "predictors"

output has been formatted without trailing spaces at the end of lines, as well as an extra line after the btb results (this matches the correct outputs given, so diff should find no differences)

takes roughly 30 seconds to run all predictors for short_trace1, which has 2 million instructions. So longer traces may take a while to run.